import os
from http.server import SimpleHTTPRequestHandler, HTTPServer
import urllib.request
import contextlib

# HTML content
html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best iPad Pro Cases Reviews</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="script.js" defer></script>
</head>
<body>
    <header>
        <div class="container">
            <h1>The Review Haven</h1>
            <nav>
                <ul class="right-menu">
                    <li><a href="#">Log in</a></li>
                    <li><a href="#" class="subscribe-button">Subscribe</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <div class="container">
            <p class="subheading">ELECTRONICS > ACCESSORIES</p>
            <h2 class="main-heading">Top 10 IPad Pro 11' Cases!</h2>
            <hr class="title-line">
            <p class="update-date">Updated June 8, 2024</p>
            <div class="social-icons">
                <a href="#"><img src="twitter.png" alt="Twitter"></a>
                <a href="https://www.instagram.com/alexandarmarques"><img src="instagram.png" alt="Instagram" class="instagram"></a>
                <a href="#" onclick="copyLink()"><img src="copy_link.png" alt="Copy Link" id="copy-link"></a>
                <a href="#"><img src="save.png" alt="Save"></a>
            </div>
            <div id="copy-bubble" class="copy-bubble">Link copied!</div>
            <article class="review">
                <img src="ipad_pro.jpg" alt="iPad Pro" class="product-image">
                <p class="product-description">Product description goes here. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin vel urna nec odio cursus malesuada.</p>
                <a href="#" class="affiliate-link">Buy Now</a>
            </article>
        </div>
    </main>
    <footer>
        <div class="container">
            <p>&copy; 2024 Best iPad Pro Cases Reviews. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
"""
# CSS content
css_content = """
body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #ffffff;
    color: #000000;
}
header {
    background-color: #ffffff;
    color: #000000;
    padding: 1rem 0;
    border-bottom: 1px solid #000000;
}
header .container {
    display: flex;
    justify-content: center;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
}
header h1 {
    font-size: 28px;
    font-weight: 500;
    margin: 0;
    text-align: center;
    font-family: 'Roboto', sans-serif;
}
header nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    position: absolute;
    right: 1rem;
}
header nav ul li {
    margin-left: 1rem;
}
header nav ul li a {
    color: #000000;
    text-decoration: none;
}
header .right-menu {
    display: flex;
}
header .right-menu .subscribe-button {
    background-color: #000000;
    color: #ffffff;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    text-decoration: none;
}
main .container {
    max-width: 1200px;
    margin: 2rem auto;
    padding: 0 1rem;
}
.subheading {
    font-weight: 500;
    color: #666;
    margin: 0 0 1rem;
    letter-spacing: 0.1em;
}
.main-heading {
    font-weight: 700;
    font-size: 36px;
    margin: 0 0 1rem;
}
.title-line {
    border: 0;
    border-top: 4px solid #000000;
    margin: 1rem 0;
}

.update-date {
    font-size: 14px;
    color: #666;
    margin-bottom: 2rem;
}
.social-icons {
    margin-bottom: 2rem;
    display: flex;
    align-items: center;
}
.social-icons a {
    margin-right: 1rem;
}
.social-icons img {
    width: 24px;
    height: 24px;
}
.instagram {
    width: 16px;
    height: 16px;
}
#copy-link {
    cursor: pointer;
}
.copy-bubble {
    display: none;
    position: absolute;
    top: 80px;
    left: 10px;
    background-color: #000000;
    color: #ffffff;
    padding: 5px 10px;
    border-radius: 5px;
    font-size: 12px;
    z-index: 1000;
}
.copy-bubble::after {
    content: '';
    position: absolute;
    bottom: 100%;
    left: 10px;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: transparent transparent #000000 transparent;
}
.product-image {
    max-width: 300px;
    height: auto;
    margin-bottom: 1rem;
}
.product-description {
    line-height: 1.6;
}
.affiliate-link {
    display: inline-block;
    margin-top: 1rem;
    padding: 0.5rem 1rem;
    background-color: #000000;
    color: #ffffff;
    text-decoration: none;
    border-radius: 4px;
}
footer {
    background-color: #ffffff;
    color: #000000;
    padding: 1rem 0;
    text-align: center;
    border-top: 1px solid #000000;
}
footer .container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
}
"""
# JavaScript content
js_content = """
function copyLink() {
    const dummy = document.createElement('textarea');
    document.body.appendChild(dummy);
    dummy.value = window.location.href;
    dummy.select();
    document.execCommand('copy');
    document.body.removeChild(dummy);
    const copyBubble = document.getElementById('copy-bubble');
    copyBubble.style.display = 'block';
    setTimeout(() => {
        copyBubble.style.display = 'none';
    }, 2000);
    const copyLinkIcon = document.getElementById('copy-link');
    copyLinkIcon.style.filter = 'invert(1)';
}
"""
# Create the necessary files
os.makedirs('site', exist_ok=True)
with open('site/index.html', 'w') as file:
    file.write(html_content)
with open('site/styles.css', 'w') as file:
    file.write(css_content)
with open('site/script.js', 'w') as file:
    file.write(js_content)
# Download an iPad image and social media icons, and save them
def download_image(url, filename):
    try:
        with contextlib.closing(urllib.request.urlopen(url)) as response:
            with open(filename, 'wb') as out_file:
                out_file.write(response.read())
    except urllib.error.HTTPError as e:
        print(f"HTTP Error: {e.code} for URL: {url}")
    except urllib.error.URLError as e:
        print(f"URL Error: {e.reason} for URL: {url}")

# URL for iPad image
image_url = "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/ipad-pro-12-11-select-202104?wid=940&hei=1112&fmt=png-alpha&.v=1617067380000"
download_image(image_url, "site/ipad_pro.jpg")
# URLs for social media icons
icons = {
    "twitter.png": "https://about.x.com/content/dam/about-twitter/x/brand-toolkit/logo-black.png.twimg.1920.png",
    "instagram.png": "https://www.lorenzateliers.at/wp-content/uploads/2023/02/instagram-png-instagram-icon-srehup-18.png",
    "save.png": "https://i.pinimg.com/564x/19/19/d8/1919d8a0007fb9d2245a22dbe245ac5d.jpg",
    "copy_link.png": "https://i.pinimg.com/564x/57/1a/b6/571ab617e509ef0589762d91457d7f73.jpg"
}
for filename, url in icons.items():
    download_image(url, f"site/{filename}")
# Serve the files
os.chdir('site')
handler = SimpleHTTPRequestHandler
port = 8000
httpd = HTTPServer(('localhost', port), handler)
print(f"Serving on http://localhost:{port}")
httpd.serve_forever()
